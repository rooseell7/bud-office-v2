# LEGACY: NOT USED

Source of truth for routing: **src/App.tsx**.
main.tsx renders `<App />`.

Do not modify. Kept for reference only.
