/**
 * LEGACY: NOT USED. Source of truth: src/App.tsx. Do not modify.
 * Сумісний proxy: якщо десь у проекті імпортують AppRouter з /router,
 * він має рендерити актуальний роутинг з src/App.tsx.
 */

export { default } from '../../App';
