/**
 * Realtime (domain events) WebSocket client. Separate from sheet collab.
 * Connects with JWT, subscribes to domain:event, join/leave project and module rooms.
 */

import { io, Socket } from 'socket.io-client';
import { wsBaseUrl } from '../shared/config/env';
import type { DomainEvent } from './types';

const DEDUP = new Set<string>();

export type RealtimeClientOptions = {
  url?: string;
  token: string | null;
  onEvent?: (ev: DomainEvent) => void;
  onConnect?: () => void;
  onDisconnect?: () => void;
};

export class RealtimeClient {
  private socket: Socket | null = null;
  private options: RealtimeClientOptions;
  private debouncedNotify: (() => void) | null = null;
  private seenIds = new Set<string>();

  constructor(options: RealtimeClientOptions) {
    this.options = options;
  }

  connect(): void {
    if (this.socket?.connected) return;
    const url = this.options.url ?? wsBaseUrl;
    this.socket = io(url, {
      auth: { token: this.options.token },
      path: '/socket.io',
      transports: ['websocket', 'polling'],
    });
    this.socket.on('connect', () => {
      this.options.onConnect?.();
    });
    this.socket.on('disconnect', () => {
      this.options.onDisconnect?.();
    });
    this.socket.on('domain:event', (ev: DomainEvent) => {
      if (!ev?.eventId) return;
      if (DEDUP.has(ev.eventId) || this.seenIds.has(ev.eventId)) return;
      DEDUP.add(ev.eventId);
      this.seenIds.add(ev.eventId);
      if (this.seenIds.size > 1000) {
        const arr = [...this.seenIds].slice(-500);
        this.seenIds.clear();
        arr.forEach((id) => this.seenIds.add(id));
      }
      this.options.onEvent?.(ev);
    });
  }

  disconnect(): void {
    this.socket?.disconnect();
    this.socket = null;
  }

  joinProject(projectId: number): void {
    this.socket?.emit('realtime', { type: 'JOIN_PROJECT', projectId });
  }

  leaveProject(projectId: number): void {
    this.socket?.emit('realtime', { type: 'LEAVE_PROJECT', projectId });
  }

  joinModule(module: 'execution' | 'finance'): void {
    this.socket?.emit('realtime', { type: 'JOIN_MODULE', module });
  }

  leaveModule(module: 'execution' | 'finance'): void {
    this.socket?.emit('realtime', { type: 'LEAVE_MODULE', module });
  }

  get connected(): boolean {
    return !!this.socket?.connected;
  }
}
