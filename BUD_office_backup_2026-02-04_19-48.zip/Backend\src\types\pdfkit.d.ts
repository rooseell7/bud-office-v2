declare module 'pdfkit' {
  const PDFDocument: any;
  export default PDFDocument;
}
