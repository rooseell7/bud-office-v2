import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { DataSource, Repository } from 'typeorm';
import { Project } from '../projects/project.entity';
import { ForemanEvent } from './foreman-event.entity';
import { CreateForemanEventDto } from './dto/create-foreman-event.dto';

export type ForemanObjectDto = {
  id: number;
  name: string;
  address?: string | null;
  status: string;
  updatedAt: string;
  openIssuesCount?: number;
  todayWorkLogsCount?: number;
};

export type ForemanEventDto = {
  id: number;
  objectId: number;
  type: string;
  payload: Record<string, any> | null;
  createdById: number | null;
  createdAt: string;
};

@Injectable()
export class ForemanService {
  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(Project)
    private readonly projectRepo: Repository<Project>,
    @InjectRepository(ForemanEvent)
    private readonly eventRepo: Repository<ForemanEvent>,
  ) {}

  async ensureForemanEventsTable(): Promise<void> {
    try {
      await this.dataSource.query(`
        CREATE TABLE IF NOT EXISTS foreman_events (
          id SERIAL PRIMARY KEY,
          "objectId" INT NOT NULL,
          type VARCHAR(64) NOT NULL,
          payload JSONB NULL,
          "createdById" INT NULL,
          "createdAt" TIMESTAMP NOT NULL DEFAULT now()
        )
      `);
      await this.dataSource.query(`
        CREATE INDEX IF NOT EXISTS idx_foreman_events_object_created
        ON foreman_events ("objectId", "createdAt")
      `);
    } catch {
      // table may exist or sync handles it
    }
  }

  async findMyObjects(userId: number): Promise<ForemanObjectDto[]> {
    const projects = await this.projectRepo.find({
      where: { foremanId: userId },
      order: { updatedAt: 'DESC' },
    });
    return projects.map((p) => ({
      id: p.id,
      name: p.name ?? '',
      address: p.address ?? null,
      status: p.status ?? 'planned',
      updatedAt: p.updatedAt?.toISOString?.() ?? new Date().toISOString(),
      openIssuesCount: 0,
      todayWorkLogsCount: 0,
    }));
  }

  async findOneObject(id: number, userId: number): Promise<any> {
    const project = await this.projectRepo.findOne({
      where: { id, foremanId: userId },
    });
    if (!project) throw new NotFoundException('Обʼєкт не знайдено');
    return {
      id: project.id,
      name: project.name ?? '',
      address: project.address ?? null,
      status: project.status ?? 'planned',
      updatedAt: project.updatedAt?.toISOString?.() ?? new Date().toISOString(),
    };
  }

  async findEvents(
    objectId: number,
    userId: number,
    limit: number,
    before?: string,
  ): Promise<ForemanEventDto[]> {
    await this.findOneObject(objectId, userId);

    const qb = this.eventRepo
      .createQueryBuilder('e')
      .where('e.objectId = :objectId', { objectId })
      .orderBy('e.createdAt', 'DESC')
      .take(limit);

    if (before) {
      const beforeDate = new Date(before);
      if (!isNaN(beforeDate.getTime())) {
        qb.andWhere('e.createdAt < :before', { before: beforeDate });
      }
    }

    const events = await qb.getMany();
    return events.map((e) => ({
      id: e.id,
      objectId: e.objectId,
      type: e.type,
      payload: e.payload ?? null,
      createdById: e.createdById ?? null,
      createdAt: e.createdAt?.toISOString?.() ?? new Date().toISOString(),
    }));
  }

  async createEvent(
    objectId: number,
    userId: number,
    dto: CreateForemanEventDto,
  ): Promise<ForemanEventDto> {
    await this.findOneObject(objectId, userId);

    const event = this.eventRepo.create({
      objectId,
      type: dto.type,
      payload: dto.payload ?? null,
      createdById: userId,
    });
    const saved = await this.eventRepo.save(event);
    return {
      id: saved.id,
      objectId: saved.objectId,
      type: saved.type,
      payload: saved.payload ?? null,
      createdById: saved.createdById ?? null,
      createdAt: saved.createdAt?.toISOString?.() ?? new Date().toISOString(),
    };
  }
}
