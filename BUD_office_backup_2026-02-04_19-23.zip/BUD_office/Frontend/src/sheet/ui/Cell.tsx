import React, { useRef, useLayoutEffect, useState } from 'react';
import { Box, Tooltip } from '@mui/material';
import type { CellCoord, CellStyle } from '../engine/types';
import type { LocaleSettings } from '../configs/types';
import { defaultLocale } from '../configs/types';
import { formatForDisplay } from '../engine/number/formatNumber';
import { CellEditor } from './CellEditor';
import { CellEditorWithAutocomplete } from './CellEditorWithAutocomplete';

export type CellProps = {
  coord: CellCoord;
  value: string;
  rawValue?: string;
  isActive: boolean;
  isInSelection: boolean;
  isInFillTarget?: boolean;
  cellStyle?: CellStyle;
  columnType?: 'text' | 'number' | 'uah' | 'percent';
  cellError?: { code: string; message: string };
  locale?: LocaleSettings;
  rowHeight?: number;
  colWidth?: number;
  flex?: boolean;
  gridCell?: boolean;
  wrap?: boolean;
  onSelect: () => void;
  onMouseEnter?: () => void;
  onDoubleClick?: () => void;
  onContextMenu?: (e: React.MouseEvent) => void;
  isEditingThis?: boolean;
  editorValue?: string;
  onEditorChange?: (value: string) => void;
  onEditorBlur?: () => void;
  autocompleteType?: 'works' | 'materials';
  onAutocompleteSelect?: (name: string, unit?: string | null) => void;
  cellComment?: string;
};

const ROW_HEIGHT = 28;
const COL_WIDTH = 100;

function getNumberFormat(
  cellStyle?: CellStyle,
  columnType?: 'text' | 'number' | 'uah' | 'percent',
): 'plain' | 'number' | 'uah' | 'percent' {
  if (cellStyle?.numberFormat && cellStyle.numberFormat !== 'plain') return cellStyle.numberFormat;
  if (columnType === 'number') return 'number';
  if (columnType === 'uah') return 'uah';
  if (columnType === 'percent') return 'percent';
  return cellStyle?.numberFormat ?? 'plain';
}

export const Cell = React.memo<CellProps>(function Cell({
  value,
  rawValue,
  isActive,
  isInSelection,
  isInFillTarget = false,
  cellStyle,
  columnType,
  cellError,
  locale = defaultLocale,
  onSelect,
  onMouseEnter,
  onDoubleClick,
  onContextMenu,
  isEditingThis = false,
  editorValue = '',
  onEditorChange,
  onEditorBlur,
  autocompleteType,
  onAutocompleteSelect,
  cellComment,
  rowHeight = ROW_HEIGHT,
  colWidth = COL_WIDTH,
  flex = false,
  gridCell = false,
  wrap = false,
}) {
  const cellRef = useRef<HTMLDivElement>(null);
  const [editorWidth, setEditorWidth] = useState(0);
  useLayoutEffect(() => {
    if (!isEditingThis || !cellRef.current) return;
    const rect = cellRef.current.getBoundingClientRect();
    setEditorWidth(rect.width);
  }, [isEditingThis]);

  const numberFormat = getNumberFormat(cellStyle, columnType);
  const isComputedErr = value === '#ERR';
  const displayValue = isComputedErr
    ? '#ERR'
    : cellError
      ? (rawValue ?? value)
      : (formatForDisplay(value, numberFormat, locale, cellStyle?.decimalPlaces) || value);
  const showErrorBorder = cellError || isComputedErr;
  return (
  <Tooltip title={cellError?.message ?? (isComputedErr ? 'Помилка обчислення' : '')} disableHoverListener={!cellError && !isComputedErr}>
  <Box
    ref={cellRef}
    onMouseDown={onSelect}
    onMouseEnter={onMouseEnter}
    onDoubleClick={onDoubleClick}
  onContextMenu={onContextMenu}
    sx={{
      position: 'relative',
      ...(gridCell
        ? { width: '100%', minWidth: 0 }
        : flex
          ? { flex: 1, minWidth: 80 }
          : { width: colWidth, minWidth: colWidth }),
      height: rowHeight,
      display: 'flex',
      alignItems: wrap ? 'flex-start' : 'center',
      justifyContent: cellStyle?.align === 'center' ? 'center' : cellStyle?.align === 'right' ? 'flex-end' : 'flex-start',
      px: isEditingThis ? 0 : 1,
      py: isEditingThis ? 0 : (wrap ? 0.5 : 0),
      fontSize: 13,
      cursor: 'cell',
      ...(wrap
        ? { whiteSpace: 'normal' as const, wordBreak: 'break-word' as const, overflowWrap: 'anywhere' as const, overflow: 'hidden' }
        : { whiteSpace: 'nowrap' as const, overflow: 'hidden', textOverflow: 'ellipsis' }),
      fontWeight: cellStyle?.bold ? 700 : 500,
      fontStyle: cellStyle?.italic ? 'italic' : undefined,
      textAlign: cellStyle?.align ?? 'left',
      borderRight: 1,
      borderBottom: 1,
      borderColor: 'var(--sheet-grid)',
      outline: isActive ? '2px solid var(--sheet-active-border)' : 'none',
      outlineOffset: -1,
      border: showErrorBorder ? '2px solid #d32f2f' : undefined,
      boxSizing: 'border-box',
      zIndex: isActive ? 1 : 0,
      color: 'var(--sheet-cell-text)',
      bgcolor: cellStyle?.fill
        ? cellStyle.fill
        : isInFillTarget
          ? 'var(--sheet-selection)'
          : isActive
            ? 'rgba(25, 118, 210, 0.12)'
            : isInSelection
              ? 'var(--sheet-selection)'
              : 'var(--sheet-cell-bg)',
    }}
  >
    {cellComment && (
      <Box
        component="span"
        title={cellComment}
        sx={{
          position: 'absolute',
          top: 2,
          right: 2,
          width: 0,
          height: 0,
          borderLeft: '6px solid transparent',
          borderTop: '6px solid #d32f2f',
          zIndex: 2,
        }}
      />
    )}
    {isEditingThis ? (
      autocompleteType && onAutocompleteSelect ? (
        <CellEditorWithAutocomplete
          value={editorValue ?? ''}
          onChange={onEditorChange ?? (() => {})}
          onBlur={onEditorBlur}
          onCommit={onEditorBlur}
          onSelectWithUnit={onAutocompleteSelect}
          rowHeight={rowHeight}
          colWidth={editorWidth > 0 ? editorWidth : (gridCell ? 200 : flex ? 200 : colWidth)}
          type={autocompleteType}
        />
      ) : (
        <CellEditor
          value={editorValue ?? ''}
          onChange={onEditorChange ?? (() => {})}
          onBlur={onEditorBlur}
          rowHeight={rowHeight}
          colWidth={editorWidth > 0 ? editorWidth : (gridCell ? 200 : flex ? 200 : colWidth)}
        />
      )
    ) : (
      displayValue
    )}
  </Box>
  </Tooltip>
  );
});
