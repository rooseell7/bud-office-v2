Frontend BigPack: hide materialId validation error
