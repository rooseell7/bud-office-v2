// FILE: src/utils/exportInvoiceXlsx.ts
// Backward-compatible re-export (used by pages copied from Invoices UX).

export { exportInvoiceXlsx } from './xlsxExport';
