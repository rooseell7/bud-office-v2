import React, { useEffect, useState } from 'react';
import { Box, CircularProgress, Typography } from '@mui/material';
import { getProjectTimeline, type TimelineEvent } from '../../../api/projects';

type Props = { projectId: number; types?: string };

function formatAt(iso: string): string {
  try {
    const d = new Date(iso);
    return d.toLocaleString('uk-UA', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  } catch {
    return iso;
  }
}

function typeLabel(type: string): string {
  const t = type.toLowerCase();
  if (t === 'quote') return 'КП';
  if (t === 'act') return 'Акт';
  if (t === 'invoice') return 'Накладна';
  if (t === 'activity') return 'Подія';
  return type;
}

export default function ProjectTimelineTab({ projectId, types }: Props) {
  const [events, setEvents] = useState<TimelineEvent[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    setLoading(true);
    setError(null);
    getProjectTimeline(projectId, { types, limit: 50 })
      .then(setEvents)
      .catch((e: any) => setError(e?.response?.data?.message || e?.message || 'Помилка завантаження'))
      .finally(() => setLoading(false));
  }, [projectId, types]);

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', py: 2 }}>
        <CircularProgress size={24} />
      </Box>
    );
  }
  if (error) {
    return <Typography color="error">{error}</Typography>;
  }
  if (events.length === 0) {
    return <Typography color="text.secondary">Немає подій за обраний період.</Typography>;
  }

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
      {events.map((ev) => (
        <Box
          key={`${ev.type}-${ev.entityId ?? ''}-${ev.at}`}
          sx={{
            display: 'flex',
            alignItems: 'flex-start',
            gap: 1,
            py: 0.5,
            borderBottom: '1px solid',
            borderColor: 'divider',
          }}
        >
          <Typography variant="caption" color="text.secondary" sx={{ minWidth: 140 }}>
            {formatAt(ev.at)}
          </Typography>
          <Typography variant="caption" sx={{ px: 0.5, borderRadius: 1, bgcolor: 'action.hover' }}>
            {typeLabel(ev.type)}
          </Typography>
          <Typography variant="body2">{ev.title}</Typography>
        </Box>
      ))}
    </Box>
  );
}
