import api from './api';

export interface ProjectSummaryDto {
  id: number;
  name: string;
  address: string | null;
  client: { id: number | string; name: string; phone: string } | null;
  salesStage: string;
  executionStatus: string | null;
}

export interface TimelineEvent {
  type: string;
  at: string;
  title: string;
  entityId?: number;
  meta?: Record<string, unknown>;
}

export interface ProjectTimelineQuery {
  from?: string;
  to?: string;
  types?: string;
  limit?: number;
}

export async function getProjectSummary(projectId: number): Promise<ProjectSummaryDto> {
  const { data } = await api.get<ProjectSummaryDto>(`/projects/${projectId}/summary`);
  return data;
}

export async function getProjectTimeline(
  projectId: number,
  query?: ProjectTimelineQuery,
): Promise<TimelineEvent[]> {
  const params = new URLSearchParams();
  if (query?.from) params.set('from', query.from);
  if (query?.to) params.set('to', query.to);
  if (query?.types) params.set('types', query.types);
  if (query?.limit != null && query.limit > 0) params.set('limit', String(query.limit));
  const url = `/projects/${projectId}/timeline` + (params.toString() ? `?${params.toString()}` : '');
  const { data } = await api.get<TimelineEvent[]>(url);
  return Array.isArray(data) ? data : [];
}
