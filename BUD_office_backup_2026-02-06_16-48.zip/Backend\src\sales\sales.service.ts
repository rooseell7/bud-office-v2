import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { In, Repository } from 'typeorm';
import { Project } from '../projects/project.entity';
import { Deal } from '../deals/deal.entity';
import { User } from '../users/user.entity';

export interface SalesProjectItemDto {
  projectId: number;
  name: string;
  address: string | null;
  client: { id: number | string; name: string } | null;
  salesStage: string;
  deal: { id: number; title: string; amount: string; stage: string; status: string } | null;
  nextAction: string | null;
  nextActionDue: string | null;
  lastContactAt: string | null;
  owner: { id: number; fullName: string } | null;
}

export interface SalesProjectsQueryDto {
  q?: string;
  salesStage?: string;
  ownerId?: number;
  nextActionBucket?: 'today' | 'this_week' | 'overdue' | 'any';
  page?: number;
  limit?: number;
}

export interface SalesProjectsResponseDto {
  items: SalesProjectItemDto[];
  total: number;
}

export interface SalesProjectDetailsDto {
  projectId: number;
  name: string;
  address: string | null;
  client: { id: number | string; name: string; phone: string } | null;
  salesStage: string;
  deal: { id: number; title: string; amount: string; stage: string; status: string } | null;
  nextAction: string | null;
  nextActionDue: string | null;
  owner: { id: number; fullName: string } | null;
}

@Injectable()
export class SalesService {
  constructor(
    @InjectRepository(Project)
    private readonly projectRepo: Repository<Project>,
    @InjectRepository(Deal)
    private readonly dealRepo: Repository<Deal>,
    @InjectRepository(User)
    private readonly userRepo: Repository<User>,
  ) {}

  async getProjectsList(query: SalesProjectsQueryDto): Promise<SalesProjectsResponseDto> {
    const page = Math.max(1, query.page ?? 1);
    const limit = Math.min(100, Math.max(1, query.limit ?? 20));
    const offset = (page - 1) * limit;

    const qb = this.projectRepo
      .createQueryBuilder('p')
      .orderBy('p.updatedAt', 'DESC');

    if (query.q?.trim()) {
      qb.andWhere('(p.name ILIKE :q OR p.address ILIKE :q)', { q: `%${query.q.trim()}%` });
    }
    if (query.salesStage?.trim()) {
      qb.andWhere('p.status = :salesStage', { salesStage: query.salesStage.trim() });
    }
    if (query.ownerId != null && Number.isFinite(query.ownerId)) {
      qb.andWhere('p.userId = :ownerId', { ownerId: query.ownerId });
    }

    const projects = await qb.getMany();
    const projectIds = projects.map((p) => p.id);
    if (projectIds.length === 0) {
      return { items: [], total: 0 };
    }

    const [deals, users] = await Promise.all([
      this.dealRepo.find({ where: { projectId: In(projectIds) } }),
      this.userRepo.find({ where: { id: In(projects.map((p) => p.userId)) }, select: ['id', 'fullName'] }),
    ]);

    const dealByProject = new Map<number, Deal>();
    for (const d of deals) {
      if (d.projectId != null && !dealByProject.has(d.projectId)) {
        dealByProject.set(d.projectId, d);
      }
    }
    const userMap = new Map(users.map((u) => [u.id, u]));

    let clientMap = new Map<number, { id: number | string; name: string }>();
    const clientIds = [...new Set(projects.map((p) => p.clientId).filter((id): id is number => id != null))];
    if (clientIds.length > 0) {
      try {
        const rows = await this.projectRepo.manager.query(
          'SELECT id, name FROM clients WHERE id = ANY($1::int[])',
          [clientIds],
        );
        for (const r of rows ?? []) {
          clientMap.set(r.id, { id: r.id, name: r.name ?? '' });
        }
      } catch {
        // ignore
      }
    }

    const items: SalesProjectItemDto[] = projects.map((p) => {
      const deal = dealByProject.get(p.id);
      const owner = userMap.get(p.userId);
      const lastContactAt = p.nextActionDue ?? (deal?.updatedAt ? new Date(deal.updatedAt).toISOString().slice(0, 10) : null);

      return {
        projectId: p.id,
        name: p.name,
        address: p.address ?? null,
        client: p.clientId != null ? (clientMap.get(p.clientId) ?? { id: p.clientId, name: '—' }) : null,
        salesStage: p.status ?? 'planned',
        deal: deal
          ? { id: deal.id, title: deal.title, amount: deal.amount, stage: deal.stage, status: deal.status }
          : null,
        nextAction: p.nextAction ?? null,
        nextActionDue: p.nextActionDue ?? null,
        lastContactAt,
        owner: owner ? { id: owner.id, fullName: owner.fullName ?? `User ${owner.id}` } : null,
      };
    });

    let filtered = items;
    if (query.nextActionBucket && query.nextActionBucket !== 'any') {
      const now = new Date();
      const today = now.toISOString().slice(0, 10);
      const weekEnd = new Date(now);
      weekEnd.setDate(weekEnd.getDate() + 7);
      const weekEndStr = weekEnd.toISOString().slice(0, 10);

      filtered = filtered.filter((i) => {
        const due = i.nextActionDue;
        if (!due) return false;
        switch (query.nextActionBucket) {
          case 'today':
            return due === today;
          case 'this_week':
            return due >= today && due <= weekEndStr;
          case 'overdue':
            return due < today;
          default:
            return true;
        }
      });
    }

    const total = filtered.length;
    const pageItems = filtered.slice(offset, offset + limit);
    return { items: pageItems, total };
  }

  async getProjectDetails(projectId: number): Promise<SalesProjectDetailsDto> {
    const project = await this.projectRepo.findOne({ where: { id: projectId } });
    if (!project) throw new NotFoundException('Проєкт не знайдено');

    let client: SalesProjectDetailsDto['client'] = null;
    if (project.clientId != null) {
      try {
        const rows = await this.projectRepo.manager.query(
          'SELECT id, name, phone FROM clients WHERE id = $1 LIMIT 1',
          [project.clientId],
        );
        if (Array.isArray(rows) && rows[0]) {
          const c = rows[0];
          client = { id: c.id, name: String(c.name ?? ''), phone: String(c.phone ?? '') };
        }
      } catch {
        // ignore
      }
    }

    const deal = await this.dealRepo.findOne({ where: { projectId } });
    const owner = await this.userRepo.findOne({ where: { id: project.userId }, select: ['id', 'fullName'] });

    return {
      projectId: project.id,
      name: project.name,
      address: project.address ?? null,
      client,
      salesStage: project.status ?? 'planned',
      deal: deal
        ? { id: deal.id, title: deal.title, amount: deal.amount, stage: deal.stage, status: deal.status }
        : null,
      nextAction: project.nextAction ?? null,
      nextActionDue: project.nextActionDue ?? null,
      owner: owner ? { id: owner.id, fullName: owner.fullName ?? `User ${owner.id}` } : null,
    };
  }
}
