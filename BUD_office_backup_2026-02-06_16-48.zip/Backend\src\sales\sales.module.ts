import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Project } from '../projects/project.entity';
import { Deal } from '../deals/deal.entity';
import { User } from '../users/user.entity';
import { ProjectsModule } from '../projects/projects.module';
import { SalesController } from './sales.controller';
import { SalesService } from './sales.service';

@Module({
  imports: [
    TypeOrmModule.forFeature([Project, Deal, User]),
    ProjectsModule,
  ],
  controllers: [SalesController],
  providers: [SalesService],
})
export class SalesModule {}
