import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Project } from './project.entity';
import { CreateProjectDto } from './dto/create-project.dto';
import { UpdateProjectDto } from './dto/update-project.dto';

export interface ProjectSummaryDto {
  id: number;
  name: string;
  address: string | null;
  client: { id: number | string; name: string; phone: string } | null;
  salesStage: string;
  executionStatus: string | null;
}

export interface TimelineEventDto {
  type: string;
  at: string;
  title: string;
  entityId?: number;
  meta?: Record<string, unknown>;
}

export interface ProjectTimelineQueryDto {
  from?: string; // YYYY-MM-DD
  to?: string;
  types?: string; // comma: quote,act,invoice,activity
  limit?: number;
}

@Injectable()
export class ProjectsService {
  constructor(
    @InjectRepository(Project)
    private readonly projectRepo: Repository<Project>,
  ) {}

  findAll(): Promise<Project[]> {
    return this.projectRepo.find({ order: { createdAt: 'DESC' } });
  }

  async findOne(id: number): Promise<Project> {
    const project = await this.projectRepo.findOne({ where: { id } });
    if (!project) throw new NotFoundException('Проєкт не знайдено');
    return project;
  }

  /** Канонічна шапка обʼєкта: id, name, address, client (якщо є), salesStage, executionStatus. */
  async getSummary(id: number): Promise<ProjectSummaryDto> {
    const project = await this.findOne(id);
    let client: ProjectSummaryDto['client'] = null;
    if (project.clientId != null) {
      try {
        const clientRow = await this.projectRepo.manager.query(
          'SELECT id, name, phone FROM clients WHERE id = $1 LIMIT 1',
          [project.clientId],
        );
        if (Array.isArray(clientRow) && clientRow[0]) {
          const c = clientRow[0];
          client = { id: c.id, name: String(c.name ?? ''), phone: String(c.phone ?? '') };
        }
      } catch {
        // клієнт може бути в іншій таблиці — залишаємо null
      }
    }
    return {
      id: project.id,
      name: project.name,
      address: project.address ?? null,
      client,
      salesStage: project.status ?? 'planned',
      executionStatus: project.status ?? null,
    };
  }

  async create(dto: CreateProjectDto): Promise<Project> {
    const project = new Project();

    project.name = dto.name;
    project.type = dto.type ?? '';
    project.address = dto.address ?? '';
    project.status = dto.status ?? 'planned';
    project.clientId = dto.clientId ?? null;
    project.foremanId = dto.foremanId ?? null;
    project.estimatorId = dto.estimatorId ?? null;
    project.supplyManagerId = dto.supplyManagerId ?? null;

    return this.projectRepo.save(project);
  }

  async update(id: number, dto: UpdateProjectDto): Promise<Project> {
    const project = await this.findOne(id);

    if (dto.name !== undefined) project.name = dto.name;
    if (dto.type !== undefined) project.type = dto.type;
    if (dto.address !== undefined) project.address = dto.address;
    if (dto.status !== undefined) project.status = dto.status;
    if (dto.clientId !== undefined) project.clientId = dto.clientId;
    if (dto.foremanId !== undefined) project.foremanId = dto.foremanId;
    if (dto.estimatorId !== undefined) project.estimatorId = dto.estimatorId;
    if (dto.supplyManagerId !== undefined) {
      project.supplyManagerId = dto.supplyManagerId;
    }
    if (dto.nextAction !== undefined) project.nextAction = dto.nextAction;
    if (dto.nextActionDue !== undefined) project.nextActionDue = dto.nextActionDue;

    return this.projectRepo.save(project);
  }

  async remove(id: number): Promise<void> {
    const project = await this.findOne(id);
    await this.projectRepo.remove(project);
  }

  /** Уніфікований таймлайн подій по об'єкту: activity_log, КП, акти, накладні. */
  async getTimeline(
    projectId: number,
    query: ProjectTimelineQueryDto,
  ): Promise<TimelineEventDto[]> {
    await this.findOne(projectId);
    const limit = Math.min(100, Math.max(1, query.limit ?? 50));
    const typesSet = query.types
      ? new Set(query.types.split(',').map((t) => t.trim().toLowerCase()).filter(Boolean))
      : null;
    const from = query.from?.trim().slice(0, 10);
    const to = query.to?.trim().slice(0, 10);

    const events: TimelineEventDto[] = [];
    const manager = this.projectRepo.manager;

    const addFrom = (type: string, at: Date | string, title: string, entityId?: number, meta?: Record<string, unknown>) => {
      const atStr = typeof at === 'string' ? at : new Date(at).toISOString();
      const atDate = atStr.slice(0, 10);
      if (from && atDate < from) return;
      if (to && atDate > to) return;
      if (typesSet && !typesSet.has(type)) return;
      events.push({ type, at: atStr, title, entityId, meta });
    };

    if (!typesSet || typesSet.has('activity')) {
      const activityRows = await manager.query(
        `SELECT id, ts, entity, action, "entityId", summary FROM activity_log
         WHERE "projectId" = $1 ORDER BY ts DESC LIMIT $2`,
        [projectId, limit],
      );
      for (const r of activityRows ?? []) {
        const at = r.ts;
        const title = r.summary ?? `${r.entity}:${r.action}`;
        addFrom('activity', at, title, r.entityId, { entity: r.entity, action: r.action });
      }
    }

    if (!typesSet || typesSet.has('quote')) {
      const rows = await manager.query(
        `SELECT id, title, status, "updatedAt" FROM documents
         WHERE type = 'quote' AND "projectId" = $1 ORDER BY "updatedAt" DESC LIMIT $2`,
        [projectId, limit],
      );
      for (const r of rows ?? []) {
        addFrom('quote', r.updatedAt, r.title ?? `КП #${r.id}`, r.id, { status: r.status });
      }
    }

    if (!typesSet || typesSet.has('act')) {
      const rows = await manager.query(
        `SELECT id, act_date AS "actDate", status, "updatedAt" FROM acts WHERE "projectId" = $1 ORDER BY "updatedAt" DESC LIMIT $2`,
        [projectId, limit],
      );
      for (const r of rows ?? []) {
        addFrom('act', r.updatedAt, `Акт #${r.id} (${r.actDate})`, r.id, { status: r.status });
      }
    }

    if (!typesSet || typesSet.has('invoice')) {
      const rows = await manager.query(
        `SELECT id, status, "updatedAt" FROM invoices WHERE "projectId" = $1 ORDER BY "updatedAt" DESC LIMIT $2`,
        [projectId, limit],
      );
      for (const r of rows ?? []) {
        addFrom('invoice', r.updatedAt, `Накладна #${r.id}`, r.id, { status: r.status });
      }
    }

    events.sort((a, b) => (b.at > a.at ? 1 : -1));
    return events.slice(0, limit);
  }
}
