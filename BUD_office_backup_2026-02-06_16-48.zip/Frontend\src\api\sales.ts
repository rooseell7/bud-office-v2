import api from './api';

export interface SalesProjectItem {
  projectId: number;
  name: string;
  address: string | null;
  client: { id: number | string; name: string } | null;
  salesStage: string;
  deal: { id: number; title: string; amount: string; stage: string; status: string } | null;
  nextAction: string | null;
  nextActionDue: string | null;
  lastContactAt: string | null;
  owner: { id: number; fullName: string } | null;
}

export interface SalesProjectsResponse {
  items: SalesProjectItem[];
  total: number;
}

export interface SalesProjectsQuery {
  q?: string;
  salesStage?: string;
  ownerId?: number;
  nextActionBucket?: 'today' | 'this_week' | 'overdue' | 'any';
  page?: number;
  limit?: number;
}

export interface SalesProjectDetails {
  projectId: number;
  name: string;
  address: string | null;
  client: { id: number | string; name: string; phone: string } | null;
  salesStage: string;
  deal: { id: number; title: string; amount: string; stage: string; status: string } | null;
  nextAction: string | null;
  nextActionDue: string | null;
  owner: { id: number; fullName: string } | null;
}

export async function getSalesProjects(query?: SalesProjectsQuery): Promise<SalesProjectsResponse> {
  const params = new URLSearchParams();
  if (query?.q != null && query.q !== '') params.set('q', query.q);
  if (query?.salesStage != null && query.salesStage !== '') params.set('salesStage', query.salesStage);
  if (query?.ownerId != null) params.set('ownerId', String(query.ownerId));
  if (query?.nextActionBucket != null && query.nextActionBucket !== 'any') params.set('nextActionBucket', query.nextActionBucket);
  if (query?.page != null && query.page > 0) params.set('page', String(query.page));
  if (query?.limit != null && query.limit > 0) params.set('limit', String(query.limit));
  const url = '/sales/projects' + (params.toString() ? `?${params.toString()}` : '');
  const { data } = await api.get<SalesProjectsResponse>(url);
  return data;
}

export async function getSalesProjectDetails(projectId: number): Promise<SalesProjectDetails> {
  const { data } = await api.get<SalesProjectDetails>(`/sales/projects/${projectId}/details`);
  return data;
}

export async function updateSalesProject(
  projectId: number,
  payload: { status?: string; nextAction?: string | null; nextActionDue?: string | null },
): Promise<void> {
  await api.patch(`/sales/projects/${projectId}`, payload);
}

export async function setNextAction(
  projectId: number,
  payload: { nextAction?: string; nextActionDue?: string },
): Promise<void> {
  await api.post(`/sales/projects/${projectId}/next-action`, payload);
}

export async function completeAction(projectId: number): Promise<void> {
  await api.post(`/sales/projects/${projectId}/complete-action`);
}
