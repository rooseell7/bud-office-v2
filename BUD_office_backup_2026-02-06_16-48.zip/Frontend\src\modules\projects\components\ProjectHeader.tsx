import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Box, Button, Chip, Stack, Typography } from '@mui/material';
import OpenInNewIcon from '@mui/icons-material/OpenInNew';
import type { ProjectSummaryDto } from '../../../api/projects';

type ViewKind = 'sales' | 'estimates';

interface ProjectHeaderProps {
  summary: ProjectSummaryDto;
  currentView: ViewKind;
}

const stageLabels: Record<string, string> = {
  planned: 'Планується',
  in_progress: 'В роботі',
  paused: 'Пауза',
  done: 'Завершено',
  kp_sent: 'КП надіслано',
  lead: 'Лід',
};

export function ProjectHeader({ summary, currentView }: ProjectHeaderProps) {
  const navigate = useNavigate();
  const projectId = summary.id;

  const openInSales = () => navigate(`/sales/projects/${projectId}`);
  const openInEstimates = () => navigate(`/estimates/projects/${projectId}`);

  return (
    <Box sx={{ mb: 2, p: 2, border: '1px solid', borderColor: 'divider', borderRadius: 2, bgcolor: 'background.paper' }}>
      <Stack direction={{ xs: 'column', sm: 'row' }} justifyContent="space-between" alignItems={{ xs: 'stretch', sm: 'center' }} spacing={2}>
        <Box>
          <Typography variant="h6" fontWeight={700}>
            {summary.name}
          </Typography>
          {summary.address && (
            <Typography variant="body2" color="text.secondary">
              {summary.address}
            </Typography>
          )}
          {summary.client && (
            <Typography variant="body2" color="text.secondary" sx={{ mt: 0.5 }}>
              Клієнт: {summary.client.name}
              {summary.client.phone ? ` · ${summary.client.phone}` : ''}
            </Typography>
          )}
          <Stack direction="row" spacing={1} sx={{ mt: 1 }} flexWrap="wrap">
            <Chip
              size="small"
              label={stageLabels[summary.salesStage] ?? summary.salesStage}
              color={summary.salesStage === 'done' ? 'success' : 'default'}
            />
            {summary.executionStatus && summary.executionStatus !== summary.salesStage && (
              <Chip size="small" label={stageLabels[summary.executionStatus] ?? summary.executionStatus} variant="outlined" />
            )}
          </Stack>
        </Box>
        <Stack direction="row" spacing={1} flexShrink={0}>
          {currentView === 'sales' && (
            <Button
              size="small"
              variant="outlined"
              startIcon={<OpenInNewIcon />}
              onClick={openInEstimates}
            >
              Відкрити в Кошторисах
            </Button>
          )}
          {currentView === 'estimates' && (
            <Button
              size="small"
              variant="outlined"
              startIcon={<OpenInNewIcon />}
              onClick={openInSales}
            >
              Відкрити в Продажах
            </Button>
          )}
        </Stack>
      </Stack>
    </Box>
  );
}
