import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Box,
  Button,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
  Typography,
} from '@mui/material';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import { getSalesProjects, type SalesProjectItem, type SalesProjectsQuery } from '../../api/sales';

function formatDate(str: string | null): string {
  if (!str) return '—';
  try {
    return new Date(str).toLocaleDateString('uk-UA', { day: '2-digit', month: '2-digit', year: 'numeric' });
  } catch {
    return '—';
  }
}

export default function SalesProjectsListPage() {
  const navigate = useNavigate();
  const [items, setItems] = useState<SalesProjectItem[]>([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [q, setQ] = useState('');
  const [salesStage, setSalesStage] = useState('');
  const [nextActionBucket, setNextActionBucket] = useState<SalesProjectsQuery['nextActionBucket']>('any');
  const [page, setPage] = useState(1);
  const limit = 20;

  const load = async () => {
    setLoading(true);
    setError(null);
    const query: SalesProjectsQuery = { page, limit };
    if (q.trim()) query.q = q.trim();
    if (salesStage.trim()) query.salesStage = salesStage.trim();
    if (nextActionBucket && nextActionBucket !== 'any') query.nextActionBucket = nextActionBucket;
    try {
      const res = await getSalesProjects(query);
      setItems(res.items);
      setTotal(res.total);
    } catch (e: any) {
      setError(e?.response?.data?.message || e?.message || 'Помилка завантаження');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, [page, nextActionBucket]);

  const handleSearch = () => {
    setPage(1);
    load();
  };

  return (
    <Box sx={{ p: 2 }}>
      <Button size="small" startIcon={<ArrowBackIcon />} onClick={() => navigate('/sales')} sx={{ mb: 1 }}>
        Назад
      </Button>
      <Typography variant="h6" sx={{ mb: 2 }}>
        Продажі — Об'єкти
      </Typography>

      <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1, mb: 2 }}>
        <TextField
          size="small"
          placeholder="Пошук (назва, адреса)"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
          sx={{ minWidth: 200 }}
        />
        <TextField
          size="small"
          placeholder="Етап продажу"
          value={salesStage}
          onChange={(e) => setSalesStage(e.target.value)}
          sx={{ minWidth: 140 }}
        />
        <Button
          variant={nextActionBucket === 'today' ? 'contained' : 'outlined'}
          size="small"
          onClick={() => setNextActionBucket(nextActionBucket === 'today' ? 'any' : 'today')}
        >
          Сьогодні
        </Button>
        <Button
          variant={nextActionBucket === 'this_week' ? 'contained' : 'outlined'}
          size="small"
          onClick={() => setNextActionBucket(nextActionBucket === 'this_week' ? 'any' : 'this_week')}
        >
          Цього тижня
        </Button>
        <Button
          variant={nextActionBucket === 'overdue' ? 'contained' : 'outlined'}
          size="small"
          color={nextActionBucket === 'overdue' ? 'warning' : 'inherit'}
          onClick={() => setNextActionBucket(nextActionBucket === 'overdue' ? 'any' : 'overdue')}
        >
          Прострочено
        </Button>
        <Button variant="contained" size="small" onClick={handleSearch}>
          Шукати
        </Button>
      </Box>

      {error && (
        <Typography color="error" sx={{ mb: 1 }}>
          {error}
        </Typography>
      )}

      {loading ? (
        <Box sx={{ display: 'flex', justifyContent: 'center', py: 3 }}>
          <Typography>Завантаження…</Typography>
        </Box>
      ) : (
        <TableContainer component={Paper}>
          <Table size="small">
            <TableHead>
              <TableRow>
                <TableCell>Об'єкт</TableCell>
                <TableCell>Клієнт</TableCell>
                <TableCell>Етап</TableCell>
                <TableCell>Угода</TableCell>
                <TableCell>Next action</TableCell>
                <TableCell>Власник</TableCell>
                <TableCell>Останній контакт</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {items.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} align="center">
                    Немає об'єктів за критеріями
                  </TableCell>
                </TableRow>
              ) : (
                items.map((row) => (
                  <TableRow
                    key={row.projectId}
                    hover
                    sx={{ cursor: 'pointer' }}
                    onClick={() => navigate(`/sales/projects/${row.projectId}`)}
                  >
                    <TableCell>
                      <Typography fontWeight={600}>{row.name}</Typography>
                      {row.address && (
                        <Typography variant="caption" color="text.secondary" display="block">
                          {row.address}
                        </Typography>
                      )}
                    </TableCell>
                    <TableCell>{row.client?.name ?? '—'}</TableCell>
                    <TableCell>{row.salesStage ?? '—'}</TableCell>
                    <TableCell>{row.deal ? `${row.deal.title} (${row.deal.amount})` : '—'}</TableCell>
                    <TableCell>{row.nextAction ?? '—'}</TableCell>
                    <TableCell>{row.owner?.fullName ?? '—'}</TableCell>
                    <TableCell>{formatDate(row.lastContactAt)}</TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </TableContainer>
      )}

      {total > limit && (
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mt: 1 }}>
          <Typography variant="body2" color="text.secondary">
            Всього: {total}
          </Typography>
          <Box sx={{ display: 'flex', gap: 0.5 }}>
            <Button size="small" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}>
              Назад
            </Button>
            <Button size="small" disabled={page * limit >= total} onClick={() => setPage((p) => p + 1)}>
              Далі
            </Button>
          </Box>
        </Box>
      )}
    </Box>
  );
}
