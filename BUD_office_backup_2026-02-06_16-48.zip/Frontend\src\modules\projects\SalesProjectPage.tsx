import React, { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import {
  Box,
  Button,
  Card,
  CardContent,
  CircularProgress,
  Divider,
  Tab,
  Tabs,
  TextField,
  Typography,
} from '@mui/material';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import OpenInNewIcon from '@mui/icons-material/OpenInNew';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import {
  getSalesProjectDetails,
  setNextAction,
  completeAction,
  type SalesProjectDetails,
} from '../../api/sales';
import { ProjectHeader } from './components/ProjectHeader';
import ProjectTimelineTab from './components/ProjectTimelineTab';
import { getProjectSummary, type ProjectSummaryDto } from '../../api/projects';

function a11yProps(index: number) {
  return { id: `sales-tab-${index}`, 'aria-controls': `sales-tabpanel-${index}` };
}

export default function SalesProjectPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const projectId = id ? Number(id) : NaN;
  const [summary, setSummary] = useState<ProjectSummaryDto | null>(null);
  const [details, setDetails] = useState<SalesProjectDetails | null>(null);
  const [tab, setTab] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [nextActionText, setNextActionText] = useState('');
  const [nextActionDue, setNextActionDue] = useState('');
  const [savingAction, setSavingAction] = useState(false);
  const [completingAction, setCompletingAction] = useState(false);

  const load = async () => {
    if (!Number.isFinite(projectId) || projectId <= 0) return;
    setLoading(true);
    setError(null);
    try {
      const [s, d] = await Promise.all([getProjectSummary(projectId), getSalesProjectDetails(projectId)]);
      setSummary(s);
      setDetails(d);
      setNextActionText(d.nextAction ?? '');
      setNextActionDue(d.nextActionDue ?? '');
    } catch (e: any) {
      setError(e?.response?.data?.message || e?.message || 'Помилка завантаження');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, [projectId]);

  const handleSaveNextAction = async () => {
    setSavingAction(true);
    try {
      await setNextAction(projectId, { nextAction: nextActionText.trim() || undefined, nextActionDue: nextActionDue.trim() || undefined });
      await load();
    } catch (e: any) {
      setError(e?.response?.data?.message || e?.message || 'Помилка збереження');
    } finally {
      setSavingAction(false);
    }
  };

  const handleCompleteAction = async () => {
    setCompletingAction(true);
    try {
      await completeAction(projectId);
      await load();
    } catch (e: any) {
      setError(e?.response?.data?.message || e?.message || 'Помилка');
    } finally {
      setCompletingAction(false);
    }
  };

  if (loading && !summary) {
    return (
      <Box sx={{ p: 2, display: 'flex', justifyContent: 'center' }}>
        <CircularProgress />
      </Box>
    );
  }
  if (error || !summary) {
    return (
      <Box sx={{ p: 2 }}>
        <Typography color="error">{error || 'Проєкт не знайдено'}</Typography>
        <Button startIcon={<ArrowBackIcon />} onClick={() => navigate(-1)} sx={{ mt: 1 }}>
          Назад
        </Button>
      </Box>
    );
  }

  const d = details!;

  return (
    <Box sx={{ p: 2 }}>
      <Button size="small" startIcon={<ArrowBackIcon />} onClick={() => navigate('/sales/projects')} sx={{ mb: 1 }}>
        Назад
      </Button>
      <ProjectHeader summary={summary} currentView="sales" />

      <Card sx={{ mt: 2 }}>
        <Tabs value={tab} onChange={(_, v) => setTab(v)} sx={{ px: 2, pt: 1 }}>
          <Tab label="Огляд" {...a11yProps(0)} />
          <Tab label="Клієнт" {...a11yProps(1)} />
          <Tab label="Угода" {...a11yProps(2)} />
          <Tab label="Дії" {...a11yProps(3)} />
          <Tab label="Документи" {...a11yProps(4)} />
          <Tab label="Таймлайн" {...a11yProps(5)} />
        </Tabs>
        <Divider />
        <CardContent>
          {tab === 0 && (
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
              <Box>
                <Typography variant="subtitle2" color="text.secondary">Next action</Typography>
                <Typography>{d.nextAction || '—'}</Typography>
                <Typography variant="caption">{d.nextActionDue ? `Термін: ${d.nextActionDue}` : ''}</Typography>
              </Box>
              <Box>
                <Typography variant="subtitle2" color="text.secondary">Угода</Typography>
                <Typography>{d.deal ? `${d.deal.title} — ${d.deal.amount} (${d.deal.stage})` : '—'}</Typography>
              </Box>
              <Box>
                <Typography variant="subtitle2" color="text.secondary">Клієнт</Typography>
                <Typography>{d.client?.name ?? '—'}</Typography>
                {d.client?.phone && <Typography variant="body2">{d.client.phone}</Typography>}
              </Box>
            </Box>
          )}
          {tab === 1 && (
            <Box>
              <Typography variant="subtitle2" color="text.secondary">Клієнт</Typography>
              <Typography fontWeight={600}>{d.client?.name ?? '—'}</Typography>
              <Typography variant="body2">Телефон: {d.client?.phone ?? '—'}</Typography>
            </Box>
          )}
          {tab === 2 && (
            <Box>
              {d.deal ? (
                <>
                  <Typography variant="subtitle2" color="text.secondary">Угода</Typography>
                  <Typography fontWeight={600}>{d.deal.title}</Typography>
                  <Typography>Сума: {d.deal.amount}</Typography>
                  <Typography>Етап: {d.deal.stage}</Typography>
                  <Typography>Статус: {d.deal.status}</Typography>
                  <Button size="small" startIcon={<OpenInNewIcon />} onClick={() => navigate('/sales/deals')}>
                    Відкрити угоди
                  </Button>
                </>
              ) : (
                <Typography color="text.secondary">Угоду по об'єкту не додано.</Typography>
              )}
            </Box>
          )}
          {tab === 3 && (
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, maxWidth: 400 }}>
              <TextField
                size="small"
                label="Наступна дія"
                fullWidth
                multiline
                value={nextActionText}
                onChange={(e) => setNextActionText(e.target.value)}
              />
              <TextField
                size="small"
                label="Термін (YYYY-MM-DD)"
                fullWidth
                value={nextActionDue}
                onChange={(e) => setNextActionDue(e.target.value)}
              />
              <Box sx={{ display: 'flex', gap: 1 }}>
                <Button variant="contained" size="small" onClick={handleSaveNextAction} disabled={savingAction}>
                  Зберегти
                </Button>
                {(d.nextAction || d.nextActionDue) && (
                  <Button
                    variant="outlined"
                    size="small"
                    startIcon={<CheckCircleIcon />}
                    onClick={handleCompleteAction}
                    disabled={completingAction}
                  >
                    Завершити дію
                  </Button>
                )}
              </Box>
            </Box>
          )}
          {tab === 4 && (
            <Box>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
                Кошториси та документи по об'єкту
              </Typography>
              <Button size="small" startIcon={<OpenInNewIcon />} onClick={() => navigate(`/estimates/projects/${projectId}`)}>
                Відкрити в Кошторисах
              </Button>
            </Box>
          )}
          {tab === 5 && <ProjectTimelineTab projectId={projectId} />}
        </CardContent>
      </Card>
    </Box>
  );
}
