import { Body, Controller, Get, Param, ParseIntPipe, Patch, Post, Query, UseGuards } from '@nestjs/common';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { PermissionsGuard } from '../auth/guards/permissions.guard';
import { Permissions } from '../auth/decorators/permissions.decorator';
import { ProjectsService } from '../projects/projects.service';
import { SalesService } from './sales.service';
import { SalesProjectsQueryDto } from './dto/sales-projects-query.dto';
import { UpdateProjectDto } from '../projects/dto/update-project.dto';

@UseGuards(JwtAuthGuard, PermissionsGuard)
@Controller('sales')
export class SalesController {
  constructor(
    private readonly salesService: SalesService,
    private readonly projectsService: ProjectsService,
  ) {}

  @Permissions('projects:read')
  @Get('projects')
  getProjectsList(@Query() q: SalesProjectsQueryDto) {
    return this.salesService.getProjectsList(q);
  }

  @Permissions('projects:read')
  @Get('projects/:id/details')
  getProjectDetails(@Param('id', ParseIntPipe) id: number) {
    return this.salesService.getProjectDetails(id);
  }

  @Permissions('projects:write')
  @Patch('projects/:id')
  updateProject(@Param('id', ParseIntPipe) id: number, @Body() dto: UpdateProjectDto) {
    return this.projectsService.update(id, dto);
  }

  @Permissions('projects:write')
  @Post('projects/:id/next-action')
  setNextAction(
    @Param('id', ParseIntPipe) id: number,
    @Body() body: { nextAction?: string; nextActionDue?: string },
  ) {
    return this.projectsService.update(id, {
      nextAction: body.nextAction ?? null,
      nextActionDue: body.nextActionDue ?? null,
    });
  }

  @Permissions('projects:write')
  @Post('projects/:id/complete-action')
  completeAction(@Param('id', ParseIntPipe) id: number) {
    return this.projectsService.update(id, { nextAction: null, nextActionDue: null });
  }
}
