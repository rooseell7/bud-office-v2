export type AppRole =
  | 'admin'
  | 'supply_head'
  | 'sales_head'
  | 'sales_manager_head'
  | 'supply_manager'
  | 'estimator';
